import express from "express";
import { registerUser, loginUser } from "../controllers/authController";

const router = express.Router();
router.post("/register", registerUser);
router.post("/login", loginUser);

/**
 * @swagger
 * /auth/login:
 *   post:
 *     summary: Logs in a user
 *     tags: [Auth]
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             properties:
 *               email:
 *                 type: string
 *               password:
 *                 type: string
 *     responses:
 *       200:
 *         description: User logged in successfully
 */
router.post('/login', loginUser);

export default router;
